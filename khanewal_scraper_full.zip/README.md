# Khanewal Sabzi Mandi Scraper (Complete)
Ready-to-use scraper with Selenium fallback + Google Sheets upload + Docker support.
Place your service_account.json in the folder, then run:

python scraper.py
