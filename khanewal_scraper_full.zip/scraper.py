# scraper.py
import requests
from bs4 import BeautifulSoup
import pandas as pd
import gspread
from oauth2client.service_account import ServiceAccountCredentials
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import time

URL = "https://www.urdupoint.com/daily-prices/vegetable-prices-in-khanewal.html"

def scrape_requests(url):
    headers = {"User-Agent": "Mozilla/5.0"}
    resp = requests.get(url, headers=headers)
    if "table" not in resp.text.lower():
        return None
    soup = BeautifulSoup(resp.content, 'html.parser')
    table = soup.find('table')
    if not table:
        return None
    rows=[]
    for tr in table.find_all('tr'):
        cols=[td.get_text(strip=True) for td in tr.find_all(['td','th'])]
        rows.append(cols)
    return pd.DataFrame(rows[1:], columns=rows[0])

def scrape_selenium(url):
    opts=Options()
    opts.add_argument("--headless")
    driver=webdriver.Chrome(options=opts)
    driver.get(url)
    time.sleep(3)
    html=driver.page_source
    driver.quit()
    soup=BeautifulSoup(html,'html.parser')
    table=soup.find('table')
    rows=[]
    for tr in table.find_all('tr'):
        cols=[td.get_text(strip=True) for td in tr.find_all(['td','th'])]
        rows.append(cols)
    return pd.DataFrame(rows[1:], columns=rows[0])

df=scrape_requests(URL)
if df is None:
    print("Requests failed → switching to Selenium")
    df=scrape_selenium(URL)

print(df)

scope=['https://spreadsheets.google.com/feeds','https://www.googleapis.com/auth/drive']
creds=ServiceAccountCredentials.from_json_keyfile_name('service_account.json',scope)
client=gspread.authorize(creds)

SHEET_NAME="Khanewal_Mandi_Prices"
try:
    sheet=client.open(SHEET_NAME).sheet1
except:
    sheet=client.create(SHEET_NAME).sheet1

sheet.clear()
sheet.update([df.columns.values.tolist()] + df.values.tolist())

print("Uploaded to Google Sheets successfully!")
